<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Student Management System</title>
	<link rel="stylesheet" type="text/css" href="style.css">

	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
<body>

	<nav>
		<label class="logo">Apana-School</label>

		<ul>
			<li><a href="">Home</a></li>
			<li><a href="contact.php">Register</a></li>
			<li><a href="about.php">About Us</a></li>
			<li><a href="login.php" class="btn btn-success">Login</a></li>
		</ul>
	</nav>


	<div class="section1">
		
		<label class="img_text">We Teach Students With Care</label>
		<img class="main_img" src="school_management.jpg">
	</div>


	<div class="container">

		<div class="row">

			<div class="col-md-4">

				<img class="welcome_img" src="school2.jpg">
				
			</div>

			<div class="col-md-8">

				<h1>Welcome to Apana-School</h1>

				<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat, laborum non quos eaque, amet porro nulla sed pariatur officiis quis voluptatum ducimus obcaecati doloremque sit voluptatem ipsa fuga reiciendis natus officia autem? Autem dolor optio iusto nihil inventore exercitationem maiores, et eligendi, natus quas, doloribus quo. Aliquam, nobis ipsa? Molestias, sit debitis. Animi accusamus quaerat odio, tempore repudiandae, veritatis ullam dolores amet optio praesentium, aspernatur quae? Laboriosam earum ducimus quas, consequatur velit soluta unde quae. Cum soluta enim architecto repellat perferendis, asperiores ab harum! Quasi laboriosam, error enim dolore magni, rem, assumenda nulla veritatis earum soluta fugit quibusdam amet voluptas!</p>
				
			</div>
			

		</div>
		

	</div>


	<center>
		<h1>Our Teachers</h1>
	</center>


	<div class="container">

		<div class="row">

			<div class="col-md-4">

				<img class="teacher" src="teacher1.jpg">

				<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet doloribus eligendi quas voluptate omnis, quasi laboriosam dicta sint labore tempora?</p>
				
			</div>

			<div class="col-md-4">

				<img class="teacher" src="teacher2.jpg">
				<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Vero, sint omnis! Enim recusandae nisi laborum dolorum reiciendis maiores nemo quaerat.</p>
				
			</div>

			<div class="col-md-4">

				<img class="teacher" src="teacher3.jpg">
				<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nostrum consequuntur veritatis ipsa rem ipsam dignissimos quidem at hic aliquam quibusdam?</p>
				
			</div>
			

		</div>
		

	</div>






	<center>
		<h1>Our Courses</h1>
	</center>


	<div class="container">

		<div class="row">

			<div class="col-md-4">

				<img class="teacher" src="web.jpg">
				<h3>Web Development</h3>
				
				
			</div>

			<div class="col-md-4">

				<img class="teacher" src="graphic.jpg">
				<h3>Graphics Design</h3>
				
			</div>

			<div class="col-md-4">

				<img class="teacher" src="marketing.png">
				<h3>Marketing</h3>
				
			</div>
			

		</div>
		

	</div>


	

	
		
	</div>


	<footer>
		<h3 class="footer_text">Hurry Up! Limited Seats are Available</h3>
	</footer>


</body>
</html>
