<?php

   $connection = mysqli_connect('localhost','root','','database_form');
   if($connection) {
    echo "connected";
   }

   if(isset($_POST)){
      $firstname = $_POST['firstname'];
      $lastname = $_POST['lastname'];
      $email = $_POST['email'];
      $mobile = $_POST['mobile'];
      
     

      $request = " insert into database_table(`firstname`, `lastname`, `email`, `mobile`) values('$firstname','$lastname','$email','$mobile') ";
      
      $result=mysqli_query($connection, $request);
      if(!$result){
        echo mysqli_connect_error();
      }

         header('location:contact.php'); 

   }else{
      echo 'something went wrong please try again!';
   }
   ?>